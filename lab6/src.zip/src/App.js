import "./App.css";
import { useCallback, useState } from "react";
import DurationExercise from "./components/DurationExercise.js";
import RepetitionExercise from "./components/RepetitionExercise.js";
const MENU_SCREEN = "menu";
const REPETITION_EXERCISE = "repetition";
const DURATION_EXERCISE = "duration";
const PUSH_UPS = 1;
const BICYCLING = 2;

let exerciseList = [
  { type: REPETITION_EXERCISE, name: "Push Ups", screen: 1 },
  { type: DURATION_EXERCISE, name: "Bicycling", screen: 2 },
  { type: REPETITION_EXERCISE, name: "Jumping Jacks", screen: 3 },
  { type: DURATION_EXERCISE, name: "Running", screen: 4 },
  { type: REPETITION_EXERCISE, name: "Sit Ups", screen: 5 },
];

function App() {
  let [currentScreen, setCurrentScreen] = useState(MENU_SCREEN);
  let [currentExercise, setCurrentExercise] = useState(DURATION_EXERCISE);
  let screenComponent = undefined;
  let exceriseButtonClick = useCallback((exercise) => {
    setCurrentExercise(exercise);
    setCurrentScreen(exercise.screen);
  });

  console.log("??", currentScreen);
  if (currentScreen === MENU_SCREEN) {
    screenComponent = (
      <div>
        <h1>Go Do Somethings</h1>
        <p>Select an exercise</p>
        <ul>
          {exerciseList.map((exercise) => {
            return (
              <li key={exercise.name}>
                <button onClick={() => exceriseButtonClick(exercise)}>
                  {exercise.name}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    );
  } else if (currentScreen === PUSH_UPS) {
    screenComponent = (
      <DurationExercise
        exercise={currentExercise}
        setMenuScreen={() => setCurrentScreen(MENU_SCREEN)}
      />
    );
  } else if (currentScreen === BICYCLING) {
    screenComponent = (
      <RepetitionExercise
        exercise={currentExercise}
        setMenuScreen={() => setCurrentScreen(MENU_SCREEN)}
      />
    );
  }

  return (
    <div className="App">
      <header className="App-header">
        <p>{screenComponent}</p>
      </header>
    </div>
  );
}

export default App;
