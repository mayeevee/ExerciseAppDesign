import StopWatch from "./StopWatch";

export default function DurationExercise({ excercise, setMenuScreen }) {
  let { name } = excercise;
  return (
    <div>
      <p>{name}</p>
      <StopWatch />
      <button onclick={setMenuScreen}>Back to Menu</button>
    </div>
  );
}
